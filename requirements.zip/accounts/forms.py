from django.contrib.auth.forms import UserCreationForm

from blog_page import forms

# class CustomUserCreationForm(UserCreationForm):
#     email =